#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtGlobal>
#include <random>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    ui->pushButton->setText("New Label");
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<double> dis(0.0, 1.0);

    double random1 = dis(gen);
    double random2 = dis(gen);
    double random3 = dis(gen);
    uint red = uint(random1 * 255);
    uint green = uint(random2 * 255);
    uint blue = uint(random3 * 255);

    QColor color = QColor::fromRgb(red, green, blue);
    ui->pushButton->setStyleSheet("background-color: " + color.name());
    ui->pushButton->setGeometry(0, 0, 384, 200);

}

